// Klik ikon ekstensi -> buka side panel (kanan layar)
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
chrome.runtime.onInstalled.addListener(() => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
});

const clean = (p) =>
  p.split('/')
    .map((s) => s.replace(/[<>:"|?*\\\x00-\x1f]/g, '_').trim())
    .filter(Boolean)
    .join('/');

// Nama file -> path tujuan (dipakai untuk fallback download lewat <a download>)
const expected = new Map();

chrome.downloads.onDeterminingFilename.addListener((item, suggest) => {
  const base = (item.filename || '').split(/[\\/]/).pop();
  if (expected.has(base)) {
    const path = expected.get(base);
    expected.delete(base);
    suggest({ filename: clean(path), conflictAction: 'uniquify' });
  } else {
    suggest();
  }
});

// Download via API lalu TUNGGU sampai benar-benar selesai & verifikasi isinya gambar
function downloadAndWait(url, filename) {
  return new Promise((resolve) => {
    let done = false;
    let id = null;
    let timer = null;

    const finish = (r) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      chrome.downloads.onChanged.removeListener(onChanged);
      resolve(r);
    };

    const check = () => {
      chrome.downloads.search({ id }, (items) => {
        const it = items && items[0];
        if (!it) return;
        if (it.state === 'complete') {
          if (it.mime && !it.mime.startsWith('image/')) {
            chrome.downloads.removeFile({ id }, () => chrome.downloads.erase({ id }));
            finish({ ok: false, error: `file bukan gambar (${it.mime})` });
          } else {
            finish({ ok: true });
          }
        } else if (it.state === 'interrupted') {
          finish({ ok: false, error: 'download terputus: ' + (it.error || 'unknown') });
        }
      });
    };

    const onChanged = (d) => {
      if (d.id === id && d.state) check();
    };

    chrome.downloads.onChanged.addListener(onChanged);
    chrome.downloads.download(
      { url, filename: clean(filename), conflictAction: 'uniquify', saveAs: false },
      (newId) => {
        if (chrome.runtime.lastError || newId === undefined) {
          return finish({ ok: false, error: (chrome.runtime.lastError && chrome.runtime.lastError.message) || 'gagal memulai download' });
        }
        id = newId;
        timer = setTimeout(() => finish({ ok: false, error: 'timeout download' }), 60000);
        check();
      }
    );
  });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'whoami') {
    sendResponse({ tabId: sender.tab ? sender.tab.id : null });
    return;
  }
  if (msg.type === 'expect') {
    expected.set(msg.base, msg.path);
    sendResponse({ ok: true });
    return;
  }
  if (msg.type === 'download') {
    downloadAndWait(msg.url, msg.filename).then(sendResponse);
    return true; // async
  }
});
