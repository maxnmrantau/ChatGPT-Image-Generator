(() => {
  if (window.__cgiLoaded) return;
  window.__cgiLoaded = true;

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const get = async (k) => (await chrome.storage.local.get(k))[k];
  const set = (o) => chrome.storage.local.set(o);
  const isRunning = async () => !!(await get('running'));
  const pad = (n) => String(n).padStart(3, '0');
  const EXT = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/webp': 'webp' };
  const DEFAULT_TIMEOUT = 90;

  // Selector ChatGPT — kalau UI berubah, cukup edit bagian ini
  const SEL = {
    input: '#prompt-textarea, div.ProseMirror[contenteditable="true"], textarea[name="prompt-textarea"]',
    send: [
      'button[data-testid="send-button"]',
      'button[data-testid="composer-submit-button"]',
      '#composer-submit-button',
      'button[aria-label="Send prompt"]',
      'button[aria-label="Send message"]',
      'button[aria-label="Kirim perintah"]',
      'button[aria-label="Kirim prompt"]',
      'button[aria-label="Kirim pesan"]'
    ].join(','),
    stop: [
      'button[data-testid="stop-button"]',
      'button[aria-label="Stop streaming"]',
      'button[aria-label="Stop generating"]',
      'button[aria-label*="Stop" i]',
      'button[aria-label*="Hentikan" i]',
      'button[aria-label*="Berhenti" i]'
    ].join(',')
  };

  let looping = false;

  async function patchProgress(patch) {
    const p = (await get('progress')) || { index: 0, results: [] };
    Object.assign(p, patch);
    await set({ progress: p });
    return p;
  }

  async function waitFor(fn, timeout = 10000, step = 300) {
    const t = Date.now();
    while (Date.now() - t < timeout) {
      const v = fn();
      if (v) return v;
      await sleep(step);
    }
    return null;
  }

  async function sleepWhileRunning(ms) {
    const t = Date.now();
    while (Date.now() - t < ms) {
      if (!(await isRunning())) return;
      await sleep(500);
    }
  }

  const isGenerating = () => !!document.querySelector(SEL.stop);
  const userCount = () => document.querySelectorAll('[data-message-author-role="user"]').length;

  // Deteksi gambar hasil generate. Sengaja longgar (tidak tergantung <article>/<section>)
  // karena struktur DOM ChatGPT sering berubah.
  function getImages() {
    const root = document.querySelector('main') || document.body;
    return [...root.querySelectorAll('img')].filter((img) => {
      const src = img.currentSrc || img.src;
      if (!src || /\.svg(\?|$)/i.test(src) || src.startsWith('data:image/svg')) return false;
      if (img.closest('[data-message-author-role="user"], form, header, nav')) return false;
      const looksGenerated =
        /^generated image/i.test(img.alt || '') ||
        !!img.closest('[class*="imagegen"]') ||
        /estuary|oaiusercontent/i.test(src);
      const size = Math.max(img.naturalWidth || 0, img.clientWidth || 0);
      return looksGenerated ? size >= 128 : size >= 300;
    });
  }

  function lastAssistantText() {
    const els = document.querySelectorAll('[data-message-author-role="assistant"]');
    const el = els[els.length - 1];
    return el ? el.innerText.trim().slice(0, 120) : '';
  }

  const norm = (s) => (s || '').replace(/\s+/g, ' ').trim();
  const turnCount = () => document.querySelectorAll('[data-testid^="conversation-turn"]').length;

  function composerText() {
    const el = document.querySelector(SEL.input);
    if (!el) return '';
    return norm(el.value !== undefined ? el.value : el.innerText);
  }

  function findSendButton() {
    return (
      [...document.querySelectorAll(SEL.send)].find((b) => !b.disabled && b.getAttribute('aria-disabled') !== 'true') ||
      null
    );
  }

  function setPrompt(el, text, mode = 0) {
    el.focus();
    if (el.tagName === 'TEXTAREA') {
      const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value').set;
      setter.call(el, text);
      el.dispatchEvent(new Event('input', { bubbles: true }));
      return;
    }
    if (mode === 2) {
      // cara terakhir: isi langsung ke DOM editor lalu kabari React lewat event input
      el.innerHTML = '';
      const p = document.createElement('p');
      p.textContent = text;
      el.appendChild(p);
      el.dispatchEvent(new InputEvent('input', { inputType: 'insertText', data: text, bubbles: true }));
      return;
    }
    const sel = window.getSelection();
    const range = document.createRange();
    range.selectNodeContents(el);
    sel.removeAllRanges();
    sel.addRange(range);
    document.execCommand('delete', false, null);
    if (mode === 0) {
      document.execCommand('insertText', false, text);
    } else {
      const dt = new DataTransfer();
      dt.setData('text/plain', text);
      el.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true }));
    }
  }

  function pressEnter(el) {
    el.focus();
    ['keydown', 'keypress', 'keyup'].forEach((type) =>
      el.dispatchEvent(
        new KeyboardEvent(type, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true })
      )
    );
  }

  async function submitPrompt(text, sendMs = 2000) {
    const first = await waitFor(() => document.querySelector(SEL.input), 30000);
    if (!first) throw new Error('Kotak prompt tidak ditemukan (selector input)');

    // 1) isi kotak prompt & pastikan benar-benar terisi
    const probe = norm(text).slice(0, 20);
    let filled = false;
    for (let mode = 0; mode < 3 && !filled; mode++) {
      const el = document.querySelector(SEL.input);
      if (!el) break;
      setPrompt(el, text, mode);
      filled = !!(await waitFor(() => composerText().includes(probe), 2500, 250));
    }
    if (!filled) throw new Error('Gagal mengisi kotak prompt');
    await sleep(500);

    // 2) kirim — "terkirim" dinilai dari beberapa sinyal sekaligus
    const snap = { users: userCount(), turns: turnCount(), path: location.pathname };
    const sent = () =>
      isGenerating() ||
      userCount() > snap.users ||
      turnCount() > snap.turns ||
      location.pathname !== snap.path ||
      composerText() === '';

    const ways = [
      async () => {
        const b = await waitFor(findSendButton, sendMs);
        if (b) b.click();
      },
      async () => {
        const el = document.querySelector(SEL.input);
        const f = el && el.closest('form');
        if (f) f.requestSubmit();
      },
      async () => {
        const el = document.querySelector(SEL.input);
        if (el) pressEnter(el);
      }
    ];
    for (const way of ways) {
      try {
        await way();
      } catch (e) {}
      if (await waitFor(sent, sendMs, 250)) return;
    }

    const btn = document.querySelector(SEL.send);
    throw new Error(
      `Prompt gagal terkirim (tombol kirim: ${
        btn ? (btn.disabled ? 'nonaktif' : 'ada') : 'tidak ditemukan'
      }; teks masih di kotak: ${composerText() ? 'ya' : 'tidak'})`
    );
  }

  async function waitForResult(before, timeoutMs) {
    const start = Date.now();
    let sawGen = false;
    let idleSince = null;
    let stableKey = '';
    let stableSince = 0;

    while (Date.now() - start < timeoutMs) {
      if (!(await isRunning())) return { status: 'stopped' };
      const gen = isGenerating();
      const imgs = getImages().filter((i) => !before.has(i.currentSrc || i.src));

      if (gen) {
        sawGen = true;
        idleSince = null;
      } else {
        if (idleSince === null) idleSince = Date.now();
        if (imgs.length && imgs.every((i) => i.complete && i.naturalWidth >= 256)) {
          const key = imgs.map((i) => i.currentSrc || i.src).join('|');
          if (key === stableKey) {
            if (Date.now() - stableSince > 3000) return { status: 'ok', imgs };
          } else {
            stableKey = key;
            stableSince = Date.now();
          }
        } else if (sawGen && !imgs.length && Date.now() - idleSince > 20000) {
          return {
            status: 'fail',
            error: 'Tidak ada gambar: ' + (lastAssistantText() || 'tanpa respons')
          };
        }
      }
      await sleep(1000);
    }
    return {
      status: 'fail',
      error: `Timeout ${Math.round(timeoutMs / 1000)} dtk (gambar terdeteksi: ${
        getImages().filter((i) => !before.has(i.currentSrc || i.src)).length
      })`
    };
  }

  // Download: 1) chrome.downloads (ditunggu sampai selesai & dicek isinya gambar)
  //           2) fallback: fetch blob di halaman lalu klik <a download>
  async function saveImage(src, name) {
    let blob = null;
    let ext = 'png';
    let fetchErr = '';
    try {
      const r = await fetch(src, { credentials: 'include' });
      if (r.ok) {
        const b = await r.blob();
        if (b.type.startsWith('image/')) {
          blob = b;
          ext = EXT[b.type] || 'png';
        } else fetchErr = `fetch bukan gambar (${b.type || 'unknown'})`;
      } else fetchErr = `fetch HTTP ${r.status}`;
    } catch (e) {
      fetchErr = 'fetch error';
    }

    const filename = `${name}.${ext}`;
    let res;
    try {
      res = await chrome.runtime.sendMessage({ type: 'download', url: src, filename });
    } catch (e) {
      res = { ok: false, error: e.message };
    }
    if (res && res.ok) return filename;

    if (blob) {
      const base = filename.split('/').pop();
      await chrome.runtime.sendMessage({ type: 'expect', base, path: filename }).catch(() => {});
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = base;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 15000);
      await sleep(1500);
      return filename;
    }
    throw new Error(`Download gagal: ${(res && res.error) || ''} ${fetchErr}`.trim());
  }

  async function processOne(prompt, i, s) {
    // pastikan ChatGPT idle dulu (supaya gambar telat dari prompt sebelumnya tidak tertukar)
    await waitFor(() => !isGenerating(), 120000);
    const before = new Set(getImages().map((x) => x.currentSrc || x.src));

    const text = (s.prefix ? s.prefix + ' ' : '') + prompt;
    const sendMs = Math.min(8, Math.max(1, +s.sendWait || 2)) * 1000;
    await submitPrompt(text, sendMs);

    const r = await waitForResult(before, (s.timeout || DEFAULT_TIMEOUT) * 1000);
    if (r.status !== 'ok') return r;

    const slug = prompt.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40) || 'image';
    const folder = s.folder || 'ChatGPT-Images';
    const files = [];
    for (let k = 0; k < r.imgs.length; k++) {
      const suffix = r.imgs.length > 1 ? '_' + (k + 1) : '';
      const src = r.imgs[k].currentSrc || r.imgs[k].src;
      files.push(await saveImage(src, `${folder}/${pad(i + 1)}_${slug}${suffix}`));
      await sleep(500);
    }
    return { status: 'ok', files };
  }

  async function run() {
    if (looping) return;
    looping = true;
    try {
      while (await isRunning()) {
        const job = await get('job');
        let prog = await get('progress');
        if (!job || !prog) break;
        const total = job.queue.length;

        if (prog.index >= total) {
          await set({ running: false });
          await patchProgress({ status: 'Selesai' });
          break;
        }

        const i = prog.index;
        await patchProgress({ status: `Memproses ${i + 1} dari ${total}` });

        let res;
        try {
          res = await processOne(job.queue[i], i, job.settings);
        } catch (e) {
          res = { status: 'fail', error: e.message || String(e) };
        }
        if (res.status === 'stopped') break;

        prog = await get('progress');
        const entry = {
          i,
          prompt: job.queue[i],
          ok: res.status === 'ok',
          files: res.files || [],
          error: res.error
        };
        const failStreak = entry.ok ? 0 : (prog.failStreak || 0) + 1;
        await patchProgress({ results: [...prog.results, entry], index: i + 1, failStreak });

        if (failStreak >= 3) {
          await set({ running: false });
          await patchProgress({ status: 'Berhenti: 3 prompt gagal berturut-turut' });
          break;
        }

        if (i + 1 < total) {
          await sleepWhileRunning(job.settings.delay * 1000 + Math.random() * 2000);
          if (!(await isRunning())) break;
          if (job.settings.newChat) {
            location.href = location.origin + '/'; // lanjut otomatis setelah halaman reload
            return;
          }
        }
      }
    } finally {
      looping = false;
    }
    if (!(await isRunning())) {
      const p = await get('progress');
      if (p && p.status && !/Selesai|Berhenti/.test(p.status)) await patchProgress({ status: 'Dihentikan' });
    }
  }

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'start') run();
  });

  // Auto-resume setelah reload/navigasi (mode chat baru) — hanya di tab yang memulai job
  (async () => {
    if (!(await isRunning())) return;
    const job = await get('job');
    const me = await chrome.runtime.sendMessage({ type: 'whoami' }).catch(() => null);
    if (job && me && job.tabId === me.tabId) {
      await sleep(2500);
      run();
    }
  })();
})();
