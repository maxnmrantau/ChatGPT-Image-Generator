const $ = (id) => document.getElementById(id);
const UI_VERSION = 2;
const lines = () => $('prompts').value.split('\n').map((s) => s.trim()).filter(Boolean);
const setMsg = (t) => ($('msg').textContent = t || '');
let state = { running: false };

function settings() {
  return {
    delay: Math.max(1, +$('delay').value || 5),
    timeout: Math.max(30, +$('timeout').value || 90),
    sendWait: Math.min(8, Math.max(1, +$('sendwait').value || 2)),
    prefix: $('prefix').value.trim(),
    newChat: $('newChat').checked
  };
}

async function saveUi() {
  await chrome.storage.local.set({
    ui: {
      v: UI_VERSION,
      prompts: $('prompts').value,
      delay: $('delay').value,
      timeout: $('timeout').value,
      sendwait: $('sendwait').value,
      prefix: $('prefix').value,
      newChat: $('newChat').checked
    }
  });
  $('count').textContent = '· ' + lines().length;
}

async function getChatTab() {
  const re = /^https:\/\/(chatgpt\.com|chat\.openai\.com)\//;
  const [active] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (active && re.test(active.url || '')) return active;
  const all = await chrome.tabs.query({ url: ['https://chatgpt.com/*', 'https://chat.openai.com/*'] });
  return all[0] || null;
}

async function start(resume) {
  setMsg('');
  const queue = lines();
  if (!queue.length) return setMsg('Isi prompt dulu.');
  const tab = await getChatTab();
  if (!tab) return setMsg('Buka tab chatgpt.com dulu.');

  let progress = { index: 0, results: [], failStreak: 0, status: 'Memulai...' };
  if (resume) {
    const o = await chrome.storage.local.get('progress');
    if (o.progress && o.progress.index < queue.length) {
      progress = { ...o.progress, failStreak: 0, status: 'Melanjutkan...' };
    }
  }
  await chrome.storage.local.set({ job: { queue, settings: settings(), tabId: tab.id }, progress, running: true });

  try {
    await chrome.tabs.sendMessage(tab.id, { type: 'start' });
  } catch (e) {
    // Tab dibuka sebelum ekstensi dipasang/di-reload → inject manual (script akan auto-resume sendiri)
    try {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
    } catch (e2) {
      await chrome.storage.local.set({ running: false });
      setMsg('Gagal terhubung ke tab ChatGPT. Refresh tab ChatGPT lalu coba lagi.');
    }
  }
}

const stop = () => chrome.storage.local.set({ running: false });

async function reset() {
  await chrome.storage.local.remove(['job', 'progress', 'running']);
  setMsg('');
}

function render(st) {
  state = st;
  const total = st.job?.queue?.length || 0;
  const p = st.progress || { index: 0, results: [] };
  const ok = p.results.filter((r) => r.ok).length;
  const fail = p.results.length - ok;
  const running = !!st.running;

  $('status').textContent = p.status || 'Siap';
  $('stats').textContent = total ? `${p.index}/${total} · ${ok} berhasil · ${fail} gagal` : '';
  $('bar').style.width = total ? Math.round((p.index / total) * 100) + '%' : '0%';

  $('pill').className = 'pill' + (running ? ' run' : '');
  $('pilltext').textContent = running ? 'Berjalan' : /Selesai/.test(p.status || '') ? 'Selesai' : 'Siap';

  const main = $('main');
  main.textContent = running ? 'Hentikan' : 'Mulai';
  main.classList.toggle('stop', running);
  $('resume').hidden = running || !(total && p.index > 0 && p.index < total);
  $('retry').hidden = running || fail === 0;

  const log = $('log');
  log.innerHTML = '';
  p.results.slice(-10).reverse().forEach((r) => {
    const li = document.createElement('li');
    if (!r.ok) li.className = 'bad';
    const ic = document.createElement('span');
    ic.className = 'ic';
    ic.textContent = r.ok ? '✓' : '✕';
    const t = document.createElement('span');
    t.className = 't';
    t.textContent = `#${r.i + 1} ${r.prompt}`;
    t.title = r.prompt;
    li.append(ic, t);
    if (!r.ok && r.error) {
      const e = document.createElement('span');
      e.className = 'err';
      e.textContent = r.error;
      t.append(e);
      t.style.whiteSpace = 'normal';
    }
    log.appendChild(li);
  });
  $('empty').hidden = p.results.length > 0;
}

const refresh = async () => render(await chrome.storage.local.get(['job', 'progress', 'running']));

(async () => {
  const { ui } = await chrome.storage.local.get('ui');
  if (ui) {
    $('prompts').value = ui.prompts || '';
    $('delay').value = ui.delay || 5;
    // pengaturan lama (default 300) diganti default baru 90
    $('timeout').value = ui.v === UI_VERSION ? ui.timeout || 90 : 90;
    $('sendwait').value = ui.sendwait || 2;
    $('prefix').value = ui.prefix || '';
    $('newChat').checked = !!ui.newChat;
  }
  $('count').textContent = '· ' + lines().length;
  await saveUi();
  await refresh();
})();

['prompts', 'delay', 'timeout', 'sendwait', 'prefix', 'newChat'].forEach((id) => $(id).addEventListener('input', saveUi));
$('sendwait').addEventListener('change', () => {
  $('sendwait').value = Math.min(8, Math.max(1, +$('sendwait').value || 2));
  saveUi();
});
$('upload').addEventListener('click', () => $('file').click());
$('clear').addEventListener('click', () => { $('prompts').value = ''; saveUi(); });
$('file').addEventListener('change', (e) => {
  const f = e.target.files[0];
  if (!f) return;
  const rd = new FileReader();
  rd.onload = () => {
    $('prompts').value = String(rd.result).replace(/\r/g, '');
    saveUi();
    e.target.value = '';
  };
  rd.readAsText(f);
});
$('main').addEventListener('click', () => (state.running ? stop() : start(false)));
$('resume').addEventListener('click', () => start(true));
$('reset').addEventListener('click', reset);
$('retry').addEventListener('click', async () => {
  const failed = (state.progress?.results || []).filter((r) => !r.ok).map((r) => r.prompt);
  if (!failed.length) return;
  $('prompts').value = failed.join('\n');
  await saveUi();
  await reset();
});
chrome.storage.onChanged.addListener(refresh);
